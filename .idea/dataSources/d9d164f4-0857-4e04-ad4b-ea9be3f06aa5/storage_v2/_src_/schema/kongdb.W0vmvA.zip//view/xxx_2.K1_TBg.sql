create view xxx_2 as
  select `xxx`.`id` AS `id`, `xxx`.`name` AS `name`, `xxx`.`country` AS `country`
  from `kongdb`.`xxx`
  where (`xxx`.`id` > 7);


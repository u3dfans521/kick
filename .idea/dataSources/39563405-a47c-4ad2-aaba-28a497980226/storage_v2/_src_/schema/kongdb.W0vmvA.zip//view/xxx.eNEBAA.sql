create view xxx as
  select `kongdb`.`person`.`id` AS `id`, `kongdb`.`person`.`name` AS `name`, `kongdb`.`person`.`country` AS `country`
  from `kongdb`.`person`
  where (`kongdb`.`person`.`id` < 10);

